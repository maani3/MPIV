import cv2
import pandas as pd
from PIL import Image
from transformers import pipeline
import torch
import face_recognition
import numpy as np
import os

# --- Configuration ---
VIDEO_PATH = "path_to_your_video.mp4"
WINDOW_SIZE = 10
FRAMES_TO_SAMPLE_PER_SECOND = 1
CHECKPOINT_INTERVAL = 5  # Save the DataFrame to CSV every N windows
OUTPUT_CSV_PATH = "emotion_analysis_results.csv"

def calculate_polarization_score(all_emotions_in_window):
    """
    Calculates a polarization score based on the distribution of emotions.
    """
    if not all_emotions_in_window:
        return 0.0

    total_faces = len(all_emotions_in_window)
    emotion_counts = {label: all_emotions_in_window.count(label) for label in set(all_emotions_in_window)}

    happy_count = emotion_counts.get('happy', 0)
    angry_count = emotion_counts.get('angry', 0)

    # Calculate the proportion of happy and angry faces
    happy_ratio = happy_count / total_faces
    angry_ratio = angry_count / total_faces

    # A simple polarization score: the product of the two opposing emotion ratios.
    # This value is maximized when both emotions are present in equal measure.
    # We add a small epsilon to avoid a score of zero if one emotion is absent.
    polarization = (happy_ratio + 0.01) * (angry_ratio + 0.01)

    # Scale the score for better readability
    return polarization * 100


def analyze_video_emotions(video_path, window_size, sample_rate, checkpoint_interval):
    """
    Analyzes emotions in a video in running windows, calculates a polarization score,
    and logs the results to a DataFrame with checkpointing.
    """
    # --- Initialization ---
    if not os.path.exists(video_path):
        print(f"Error: Video file not found at {video_path}")
        return

    # Initialize DataFrame
    results_df = pd.DataFrame(columns=['window_number', 'start_time', 'end_time', 'polarization_score', 'total_faces'])

    # Set up the device for inference (GPU if available)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using {device.upper()} for inference.")

    # Load the emotion classification pipeline
    emotion_classifier = pipeline(
        'image-classification',
        model='dima806/facial_emotions_image_detection',
        device=device
    )

    # --- Video Processing ---
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_interval = int(fps / sample_rate)

    window_number = 0
    frame_count = 0
    all_emotions_in_window = []

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        current_time = frame_count / fps

        # Process the frame if it's at the desired sampling interval
        if frame_count % frame_interval == 0:
            print(f"Processing frame {frame_count} at {current_time:.2f}s...")

            # Convert frame from BGR (OpenCV) to RGB
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            # Detect faces in the frame
            face_locations = face_recognition.face_locations(rgb_frame)
            print(f"  - Found {len(face_locations)} face(s).")

            for top, right, bottom, left in face_locations:
                # Crop the face from the frame
                face_image = rgb_frame[top:bottom, left:right]
                face_pil = Image.fromarray(face_image)

                # Classify emotion for the detected face
                try:
                    results = emotion_classifier(face_pil, top_k=1)
                    if results:
                        top_emotion = results[0]['label']
                        all_emotions_in_window.append(top_emotion)
                except Exception as e:
                    print(f"Could not classify a face: {e}")


        # --- Window Management ---
        if current_time >= (window_number + 1) * window_size:
            # Calculate and print the polarization score for the completed window
            score = calculate_polarization_score(all_emotions_in_window)
            start_time = window_number * window_size
            end_time = (window_number + 1) * window_size
            total_faces = len(all_emotions_in_window)

            print("\n" + "="*50)
            print(f"Window {window_number + 1} ({start_time:.2f}s - {end_time:.2f}s):")
            print(f"  - Faces Detected: {total_faces}")
            print(f"  - Polarization Score: {score:.4f}")
            print("="*50 + "\n")

            # Log results to DataFrame
            new_row = pd.DataFrame({
                'window_number': [window_number + 1],
                'start_time': [start_time],
                'end_time': [end_time],
                'polarization_score': [score],
                'total_faces': [total_faces]
            })
            results_df = pd.concat([results_df, new_row], ignore_index=True)


            # Checkpointing
            if (window_number + 1) % checkpoint_interval == 0:
                print(f"--- Checkpoint: Saving results to {OUTPUT_CSV_PATH} ---")
                results_df.to_csv(OUTPUT_CSV_PATH, index=False)


            # Reset for the next window
            window_number += 1
            all_emotions_in_window = []

        frame_count += 1

    # --- Final Window and Save ---
    if all_emotions_in_window:
        score = calculate_polarization_score(all_emotions_in_window)
        start_time = window_number * window_size
        end_time = current_time
        total_faces = len(all_emotions_in_window)

        print("\n" + "="*50)
        print(f"Final Window ({start_time:.2f}s - {end_time:.2f}s):")
        print(f"  - Faces Detected: {total_faces}")
        print(f"  - Polarization Score: {score:.4f}")
        print("="*50 + "\n")

        # Log results for the final window
        new_row = pd.DataFrame({
            'window_number': [window_number + 1],
            'start_time': [start_time],
            'end_time': [end_time],
            'polarization_score': [score],
            'total_faces': [total_faces]
        })
        results_df = pd.concat([results_df, new_row], ignore_index=True)


    # Final save of the DataFrame to CSV
    print(f"--- Final Save: Saving all results to {OUTPUT_CSV_PATH} ---")
    results_df.to_csv(OUTPUT_CSV_PATH, index=False)


    cap.release()
    print("Video analysis complete.")
    print(f"Results saved to {OUTPUT_CSV_PATH}")


if __name__ == "__main__":
    analyze_video_emotions(VIDEO_PATH, WINDOW_SIZE, FRAMES_TO_SAMPLE_PER_SECOND, CHECKPOINT_INTERVAL)